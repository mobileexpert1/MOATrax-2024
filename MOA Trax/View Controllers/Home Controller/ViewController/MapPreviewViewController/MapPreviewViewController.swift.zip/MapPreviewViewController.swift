//
//  MapPreviewViewController.swift
//  geolocate
//
//  Created by love on 13/10/21.
//

import UIKit
import PDFKit
//import GeoTiffDecoder
import CoreLocation
import MapboxStatic
// swiftlint:disable identifier_name
// swiftlint:disable line_length
// swiftlint:disable empty_count
protocol UpdateMainViewControllerLocalTracksValuesDelegate {
    func updateMainViewControllerLocalResponse(isBack:Bool)
    func checkNameExistOrNot(pdfName:String) -> Bool
}

class MapPreviewViewController: UIViewController {
    
    @IBOutlet weak var pdfTitleLbl: UILabel!
    @IBOutlet weak var currentCoordinateLbl: UILabel!
    @IBOutlet weak var pdfContainerView: UIView!
    
    var delegate: UpdateMainViewControllerLocalTracksValuesDelegate?
    var mapItem: MapFile?
    var isComeFromMapScreen = false
    var mapInfoJson: MapInfoJson?
    //var coordinates: Coordinates?
    var coordinates : CGRect?
    var pdfController: PdfViewViewController? {
        return self.children.compactMap({ $0 as? PdfViewViewController }).first
    }
    
    let currentmarkerImagView: UIImageView = {
        let imageView = UIImageView.init(frame: CGRect.init(x: 0, y: 0, width: 18, height: 18))
        imageView.image = #imageLiteral(resourceName: "ic_currentLoc")
        return imageView
    }()
    
    let locationManager = CLLocationManager()
    var currentLocation: CLLocationCoordinate2D?
    var localTempLocation: CLLocationCoordinate2D?
    var visibleScrollViewRect: CGRect?
    var zooomLevel: CGFloat?
    var trackingLocations: [CLLocationCoordinate2D] = []
    var trackingMarkers: [UIImageView] = []
    
    var isFirstLoad = true
    var isSecondLoad = true
    
    let mapSaveResource = MapSaveLocalResource()
    var countForSkipLocation = 0
    var distanceBetween = 0
    var previousLocation: CLLocation?
    override func viewDidLoad() {
        super.viewDidLoad()
        self.initPdfView()
        self.initMapData()
        
    }
    
    override func viewWillAppear(_ animated: Bool) {
        super.viewWillAppear(animated)
        UIApplication.shared.isIdleTimerDisabled = true
        UserDefaultsUtils.saveUserLoggedInValue(true, keyValue: UserProfileKeys.isLoggedInMapScreen.rawValue)
    }
    
    override func viewWillDisappear(_ animated: Bool) {
        super.viewWillDisappear(animated)
        UIApplication.shared.isIdleTimerDisabled = false
    }

    func initMapData() {
        guard let mapItem = mapItem else {
            return
        }
        self.mapInfoJson = decodeMapInfo(with: mapItem.mapInfoJSON ?? "")
        
        guard let mapInfoJson = mapInfoJson else {
            return
        }
        
//        let position = CGPoint.init(x: mapInfoJson.rasterXYsize.first!, y: mapInfoJson.rasterXYsize.last!)
//        let pointerVal: UnsafePointer<Int8>? = NSString(string: mapInfoJson.projection).utf8String
//        let transform = mapInfoJson.geotransform
//        let (easting, northing) = calculateCoordinates(x: 100, y: 100, geotransform: transform)
//        let data = mapInfoJson.rasterXYsize
//        print("Easting: \(easting), Northing: \(northing)")
//        // Calculate top-left coordinates
//        let topLeftX = transform[0]
//        let topLeftY = transform[3]

        // Calculate bottom-right coordinates
//        if let rasterXYsize = data as? [Int] {
//            let rasterWidth = rasterXYsize[0]
//            let rasterHeight = rasterXYsize[1]
//            let bottomRightX = topLeftX + (Double(rasterWidth) * transform[1]) + (Double(rasterHeight) * transform[2])
//            let bottomRightY = topLeftY + (Double(rasterWidth) * transform[4]) + (Double(rasterHeight) * transform[5])
//
//            // Create a bounding box
//            let boundingBox = CGRect(x: topLeftX, y: topLeftY, width: bottomRightX - topLeftX, height: bottomRightY - topLeftY)
//
//            print("Bounding Box: \(boundingBox)")
//            self.coordinates = boundingBox
//            self.fetchInitialPinCoordinates()
//            self.initCurrentLocation()
//        }
        
        
    //    /*
         let position = CGPoint.init(x: mapInfoJson.rasterXYsize.first!, y: mapInfoJson.rasterXYsize.last!)
         let pointerVal: UnsafePointer<Int8>? = NSString(string: mapInfoJson.projection).utf8String
         let projectionString = String(cString: pointerVal!)
        
        
        let jsonString = mapItem.mapInfoJSON ?? ""
        if let result = extractLatLongAndSize(from: jsonString) {
            print("Latitude: \(result.latitude), Longitude: \(result.longitude), Image Size: \(result.imageSize)")
            let pdfCoordinateBounds = CGRect(x: result.latitude, y: result.longitude, width: result.imageSize.width, height: result.imageSize.height)
            self.coordinates = pdfCoordinateBounds
            self.fetchInitialPinCoordinates()
            self.initCurrentLocation()
        }
        
        /*
         fetchPdfCoordinateBounds(with: position, projection: projectionString, initialTransform: mapInfoJson.geotransform, size: pdfController?.page.size ?? .zero) { bounds, latitude, longitude, error in
             if let error = error {
                 print("Error fetching bounds: \(error)")
                 return
             }
             if bounds == nil {
                 print("No coordinate bounds found")
                 return
             }
             
             print("PDF Coordinate Bounds: \(bounds)")
             self.coordinates = bounds
             self.fetchInitialPinCoordinates()
             self.initCurrentLocation()
             print("PDF Bounds: \(bounds), Latitude: \(latitude), Longitude: \(longitude)")
             // Use bounds, latitude, and longitude as needed
         }
         */
        

    //     */
        
        /*
         let decoder = GeoDecode()
         decoder.fetchPdfCoordinateBounds(with: position, projection: pointerVal, initialTransform: mapInfoJson.geotransform) { coordinate, error in
             if let error = error {
                 debugPrint(error)
             } else {
                 
                 guard let coordinate = coordinate else {
                     return
                 }
                 self.coordinates = coordinate
                 self.fetchInitialPinCoordinates()
                 self.initCurrentLocation()
             }
         }
         */
      
    }
    

    func calculatePDFCoordinateBounds(rasterXYSize: [Int], geotransform: [Double]) -> PDFCoordinateBounds {
        let xMin = geotransform[0]
        let yMin = geotransform[3]
        let xMax = xMin + Double(rasterXYSize[0]) * geotransform[1]
        let yMax = yMin + Double(rasterXYSize[1]) * geotransform[5]
        return PDFCoordinateBounds(xMin: xMin, yMin: yMin, xMax: xMax, yMax: yMax)
    }
    func fetchPdfCoordinateBounds(with position: CGPoint,
                                  projection: String,
                                  initialTransform: [Double],size : CGSize,
                                  completion: @escaping (_ coordinate: CGRect, _ latitude: Double, _ longitude: Double, _ error: Error?) -> Void) {
        
        var projectionParams: [String: Double] = [:]
        var geotransform: [Double] = initialTransform
        
        print("Projection String: \(projection)") // Debugging line

        // Check for PROJ4 extension
        let proj4Regex = try? NSRegularExpression(pattern: "EXTENSION\\s*\\[\\s*\"PROJ4\"\\s*,\\s*\"([^\"]+)\"\\s*\\]", options: [])
        let proj4Matches = proj4Regex?.matches(in: projection, options: [], range: NSRange(location: 0, length: projection.utf16.count))

        if let match = proj4Matches?.first {
            // Extract PROJ4 string
            if let range = Range(match.range(at: 1), in: projection) {
                let proj4String = String(projection[range])
                // Parse PROJ4 string
                let proj4Components = proj4String.components(separatedBy: " +")
                for component in proj4Components {
                    let keyValue = component.components(separatedBy: "=")
                    if keyValue.count == 2, let value = Double(keyValue[1]) {
                        projectionParams[keyValue[0]] = value
                    }
                }
                print("Projection Parameters from PROJ4: ", projectionParams)
            }
        } else {
            // If no PROJ4 extension, check for parameters directly
            print("No PROJ4 extension found, checking for parameters in projection string.")
            let parametersRegex = try? NSRegularExpression(pattern: "PARAMETER\\s*\\[\\s*\"([^\"]+)\"\\s*,\\s*([-+]?[0-9]*\\.?[0-9]+)\\s*\\]", options: [])
            let parametersMatches = parametersRegex?.matches(in: projection, options: [], range: NSRange(location: 0, length: projection.utf16.count))
            
            if let matches = parametersMatches {
                for match in matches {
                    if let keyRange = Range(match.range(at: 1), in: projection),
                       let valueRange = Range(match.range(at: 2), in: projection) {
                        let key = String(projection[keyRange])
                        if let value = Double(projection[valueRange]) {
                            projectionParams[key] = value
                        }
                    }
                }
                print("Projection Parameters from Projection String: ", projectionParams)
            } else {
                print("No parameter matches found for the regex.") // Debugging line
                completion(CGRect.zero, 0, 0, NSError(domain: "InvalidProjection", code: 1, userInfo: [NSLocalizedDescriptionKey: "No projection parameters found."]))
                return
            }
        }

        print("Geotransform Values (from initialTransform): ", geotransform)

            // Ensure the geotransform array has enough elements
            guard geotransform.count >= 6 else {
                completion(CGRect.zero, 0, 0, NSError(domain: "InvalidGeotransform", code: 1, userInfo: [NSLocalizedDescriptionKey: "Geotransform array must have at least 6 elements."]))
                return
            }
        // Calculate the coordinates using the initial transform
//        let x = position.x * initialTransform[1] + position.y * initialTransform[2] + initialTransform[0]
//        let y = position.x * initialTransform[4] + position.y * initialTransform[5] + initialTransform[3]
//        
//        // Use projection parameters for latitude and longitude calculations
//        let a = projectionParams["a"] ?? 6378137 // Default to WGS 84 if "a" isn't found
//        let latitude = (y - geotransform[3]) / a
//        let longitude = (x - geotransform[0]) / a
//        
//        let easting = geotransform[0] // UTM easting
//        let northing = geotransform[3] // UTM northing
//        let zone = 17 // Replace this with your dynamic zone value if necessary

        let jsonString = mapItem?.mapInfoJSON ?? ""
        if let result = extractLatLongAndSize(from: jsonString) {
            print("Latitude: \(result.latitude), Longitude: \(result.longitude), Image Size: \(result.imageSize)")
            let pdfCoordinateBounds = CGRect(x: result.latitude, y: result.longitude, width:result.imageSize.width, height: result.imageSize.height) //(size.height / 2) * 1/10
            completion(pdfCoordinateBounds, result.latitude, result.longitude, nil)
        }
    }
    func extractUtmZone(from projection: String) -> Int {
        // Simple extraction logic for UTM zone, assuming the format is known
        let components = projection.components(separatedBy: "zone ")
        if components.count > 1, let zoneString = components[1].prefix(3).split(separator: "N").first {
            return Int(zoneString) ?? 0
        }
        return 0
    }
    
    func mercatorToLatLong(x: Double, y: Double) -> CLLocationCoordinate2D {
        let longitude = x * 180.0 / 20037508.34
        let latitude = (180.0 / Double.pi) * atan(sinh(Double.pi * (y / 20037508.34)))
        return CLLocationCoordinate2D(latitude: latitude, longitude: longitude)
    }

    func convertGeoToLatLong(from jsonString: String) -> CLLocationCoordinate2D? {
        print("Input JSON: \(jsonString)") // Print the JSON string for debugging
        
        guard let jsonData = jsonString.data(using: .utf8) else {
            print("Error converting string to data")
            return nil
        }
        
        do {
            if let json = try JSONSerialization.jsonObject(with: jsonData, options: []) as? [String: Any],
               let geotransform = json["geotransform"] as? [Double],
               geotransform.count >= 6 {
                
                let projection = json["projection"] as? String ?? ""

                if projection.contains("WGS_1984_Web_Mercator") {
                    // Handle Web Mercator
                    let x = geotransform[0] // x coordinate
                    let y = geotransform[3] // y coordinate
                    return mercatorToLatLong(x: x, y: y)
                } else if projection.contains("UTM") {
                    // Handle UTM
                    let easting = geotransform[0] // UTM easting
                    let northing = geotransform[3] // UTM northing
                    let zone = extractUtmZone(from: projection) // Extract UTM zone dynamically
                    return utmToLatLong(easting: easting, northing: northing, zone: zone)
                } else {
                    print("Unknown projection type")
                }
            } else {
                print("Error extracting geotransform")
            }
        } catch {
            print("Error parsing JSON: \(error)")
        }
        return nil
    }
    func utmToLatLong(easting: Double, northing: Double, zone: Int) -> CLLocationCoordinate2D {
        let k0 = 0.9996
        let a = 6378137.0 // WGS 84 major axis
        let e = 0.081819191 // WGS 84 first eccentricity
        let e1sq = 0.006739497 // e^2 / (1-e^2)

        let x = easting - 500000.0
        let y = northing

        let m = y / k0
        let mu = m / (a * (1.0 - (e * e) / 4.0 - 3.0 * (e * e * e * e) / 64.0 - 5.0 * (e * e * e * e * e * e) / 256.0))

        let phi1Rad = mu + (3.0 * e1sq / 2.0 - 27.0 * e1sq * e1sq * e1sq / 32.0) * sin(2.0 * mu) + (21.0 * e1sq * e1sq / 16.0 - 55.0 * e1sq * e1sq * e1sq * e1sq / 32.0) * sin(4.0 * mu)
        
        let n1 = a / sqrt(1 - e * e * sin(phi1Rad) * sin(phi1Rad))
        let r1 = a * (1 - e * e) / pow(1 - e * e * sin(phi1Rad) * sin(phi1Rad), 1.5)
        let d = x / (n1 * k0)

        let latitude = phi1Rad - (n1 * tan(phi1Rad) / r1) * (d * d / 2.0 - (5.0 + 3.0 * tan(phi1Rad) * tan(phi1Rad) + e1sq * (1 - 2.0 * e1sq)) * pow(d, 4.0) / 24.0)
        let longitude = (Double(zone) - 1.0) * 6.0 - 180.0 + (d / cos(phi1Rad))

        return CLLocationCoordinate2D(latitude: latitude * 180.0 / .pi, longitude: longitude)
    }

    func convertUTMToLatLong(from jsonString: String) {
        print("Input JSON: \(jsonString)") // Print the JSON string for debugging
        
        guard let jsonData = jsonString.data(using: .utf8) else {
            print("Error converting string to data")
            return
        }
        
        do {
            if let json = try JSONSerialization.jsonObject(with: jsonData, options: []) as? [String: Any],
               let geotransform = json["geotransform"] as? [Double],
               geotransform.count >= 6 {
                
                let easting = geotransform[0] // UTM easting
                let northing = geotransform[3] // UTM northing
                let zone = 17 // Replace this with your dynamic zone value if necessary

                // Convert UTM to latitude and longitude
                let latLong = utmToLatLong(easting: easting, northing: northing, zone: zone)
                print("Latitude: \(latLong.latitude), Longitude: \(latLong.longitude)")
            } else {
                print("Error extracting geotransform")
            }
        } catch {
            print("Error parsing JSON: \(error)")
        }
    }
    func extractLatLongAndSize(from jsonString: String) -> (latitude: Double, longitude: Double, imageSize: CGSize)? {
        // Convert JSON string to Data
        guard let jsonData = jsonString.data(using: .utf8) else {
            print("Failed to convert string to data.")
            return nil
        }
        // Decode JSON
        let decoder = JSONDecoder()
        do {
            let rasterData = try decoder.decode(RasterData.self, from: jsonData)
            // Extract size
            let width = rasterData.rasterXYsize[0]
            let height = rasterData.rasterXYsize[1]
            
            // Extract geotransform values
            let originX = rasterData.geotransform[0] // Upper left X
            let pixelSizeX = rasterData.geotransform[1] // Pixel size in X
            let originY = rasterData.geotransform[3] // Upper left Y
            let pixelSizeY = rasterData.geotransform[5] // Pixel size in Y
            
            // Determine projection type
            var centerLongitude: Double
            var centerLatitude: Double
            
            if rasterData.projection.contains("WGS_1984_Web_Mercator") {
                // WGS 1984 Web Mercator calculations
                (centerLatitude, centerLongitude) = calculateWGS84Coordinates(originX: originX, originY: originY, width: width, height: height, pixelSizeX: pixelSizeX, pixelSizeY: pixelSizeY)
            } else if rasterData.projection.contains("NAD83 / UTM zone 17N") {
                (centerLatitude, centerLongitude) = calculateUTMCoordinates(originX: originX, originY: originY, width: width, height: height, pixelSizeX: pixelSizeX, pixelSizeY: pixelSizeY)
            } else {
                print("Unsupported projection type.")
                return nil
            }
            
            // Create CGSize for the image view
            let imageSize = CGSize(width: width, height: height)
            
            return (latitude: centerLatitude, longitude: centerLongitude, imageSize: imageSize)
            
        } catch {
            print("Error decoding JSON: \(error)")
            return nil
        }
    }
    
    // Calculate coordinates for WGS 1984 Web Mercator
    func calculateWGS84Coordinates(originX: Double, originY: Double, width: Int, height: Int, pixelSizeX: Double, pixelSizeY: Double) -> (Double, Double) {
        let R: Double = 6378137 // Earth's radius in meters
        let centerX = originX + (Double(width) * pixelSizeX) / 2.0
        let centerY = originY + (Double(height) * pixelSizeY) / 2.0

        let centerLongitude = (centerX / R) * (180 / .pi)
        let centerLatitude = (180 / .pi) * (atan(sinh(centerY / R)))

        return (centerLatitude, centerLongitude)
    }

    // Calculate coordinates for NAD83 UTM Zone 17N
    func calculateUTMCoordinates(originX: Double, originY: Double, width: Int, height: Int, pixelSizeX: Double, pixelSizeY: Double) -> (Double, Double) {
        // Constants for UTM
        let falseEasting = 500000.0
        let scaleFactor = 0.9996
        let a = 6378137.0 // Equatorial radius of the WGS84 ellipsoid
        let e = 0.081819190842622 // Eccentricity
        let e1sq = e * e / (1 - e * e) // e squared

        // Calculate easting and northing
        let easting = originX + (Double(width) * pixelSizeX) / 2.0
        let northing = originY + (Double(height) * pixelSizeY) / 2.0

        // Adjust northing for southern hemisphere
        var N = northing
        if N < 0 {
            N += 10000000.0 // Add false northing if in southern hemisphere
        }

        // Calculate the meridional arc
        let m = N / scaleFactor

        // Calculate the footpoint latitude
        let mu = m / (a * (1.0 - e * e / 4.0 - 3.0 * e * e * e * e / 64.0 - 5.0 * e * e * e * e * e * e / 256.0))

        // Calculate latitude
        let phi1 = mu + (3.0 * e1sq / 2.0 - 27.0 * e1sq * e1sq * e1sq / 32.0) * sin(2.0 * mu) +
                    (21.0 * e1sq * e1sq / 16.0 - 55.0 * e1sq * e1sq * e1sq * e1sq / 32.0) * sin(4.0 * mu) +
                    (151.0 * e1sq * e1sq * e1sq / 96.0) * sin(6.0 * mu)

        // Calculate N1 and other variables
        let n1 = a / sqrt(1.0 - e * e * sin(phi1) * sin(phi1))
        let t1 = tan(phi1) * tan(phi1)
        let c1 = e1sq * cos(phi1) * cos(phi1)
        let r1 = a * (1.0 - e * e) / pow(1.0 - e * e * sin(phi1) * sin(phi1), 1.5)
        let d = (easting - falseEasting) / (n1 * scaleFactor)

        // Latitude in radians
        let centerLatitude = phi1 - (n1 * tan(phi1) / r1) * (d * d / 2.0 -
            (5.0 + 3.0 * t1 + 10.0 * c1 - 4.0 * c1 * c1 - 9.0 * e1sq) * d * d * d * d / 24.0 +
            (61.0 + 90.0 * t1 + 298.0 * c1 + 45.0 * t1 * t1 - 252.0 * e1sq - 3.0 * c1 * c1) * d * d * d * d * d / 720.0)

        // Longitude in radians
        let centerLongitude = (d - (1.0 + 2.0 * t1 + c1) * d * d * d / 6.0 +
            (5.0 - 2.0 * c1 + 28.0 * t1 - 3.0 * c1 * c1 + 8.0 * e1sq) * d * d * d * d * d / 120.0) / cos(phi1)
        let longitude = centerLongitude * (180.0 / .pi) +  (originX / 6367449.145) * (180 / .pi)

        // Return latitude and longitude
        return (centerLatitude * (180.0 / .pi), longitude)
    }
    
    func initPdfView() {
        guard let mapFile = mapItem else { return }
        do {
            self.pdfTitleLbl.text = mapFile.mapFileName
            let paths = NSSearchPathForDirectoriesInDomains(FileManager.SearchPathDirectory.documentDirectory, FileManager.SearchPathDomainMask.userDomainMask, true)
            if let path = paths.first {
                let fileURL = URL(fileURLWithPath: path).appendingPathComponent(mapFile.mapFileName ?? "")
                let document = try PDFDocument.init(at: fileURL)
                pdfController?.page = try document.page(0)
                pdfController?.scrollDelegates = self
                pdfController?.scrollView.layoutSubviews()
            }
        } catch {
            ToastUtils.shared.showToast(with: error.localizedDescription)
        }
    }
    
    func decodeMapInfo(with value: String) -> MapInfoJson? {
        do {
            guard let valueData = value.data(using: .utf8) else {
                return nil
            }
            let decodedResult = try JSONDecoder().decode(MapInfoJson.self, from: valueData)
            return decodedResult
        } catch {
            print("error: ", error)
        }
        return nil
    }
    
    @IBAction func zoomOutBtnAction(_ sender: UIButton) {
        guard let pdfController = pdfController else { return }
        pdfController.scrollView.setZoomScale(0.0, animated: true)
    }
    
    @IBAction func backBtnAction(_ sender: UIButton) {
        if isPresentOnCoordinates() {
            if distanceBetween != 0 {
                showAlertWhenUserClickBackButton(title: MapDetailScreenConstant.AttensionStr, message: MapDetailScreenConstant.TitleForTrackingSavePointsStr, isForSaveName: false, FirstButtonName: MapDetailScreenConstant.SaveStr, SecondButtonName: MapDetailScreenConstant.CancelStr)
            }else{
                self.navigationController?.popViewController(animated: true)
                UserDefaultsUtils.saveUserLoggedInValue(false, keyValue: UserProfileKeys.isLoggedInMapScreen.rawValue)
            }
        } else {
            self.navigationController?.popViewController(animated: true)
            UserDefaultsUtils.saveUserLoggedInValue(false, keyValue: UserProfileKeys.isLoggedInMapScreen.rawValue)
        }
        locationManager.stopUpdatingLocation()
    }
}

extension MapPreviewViewController: scrollViewActions {
    
    func scrollViewScroll(_ sender: UIScrollView) {
        let visibleRect = CGRect.init(x: sender.contentOffset.x, y: sender.contentOffset.y, width: sender.contentSize.width*sender.zoomScale, height: sender.contentSize.height*sender.zoomScale)
        self.visibleScrollViewRect = visibleRect
        self.zooomLevel = sender.zoomScale
        if coordinates != nil {
            updatePinCoordinates(with: self.visibleScrollViewRect!, zoomScale: sender.zoomScale)
            if  isFirstLoad || isSecondLoad {
                self.getLocalPointsWithParticularSessionId()
            }
       }
    }
    
    func fetchInitialPinCoordinates() { //check
        guard let coordinates = coordinates else { return }
        
        let latitude = coordinates.maxX - (0.5 * (coordinates.maxX - coordinates.minX))
        let longitude = coordinates.minY + (0.5 * (coordinates.maxY - coordinates.minY))
        
        self.currentCoordinateLbl.text = "\(coordinates.minX)" + "," + "\(coordinates.minY)"
    }
    
    func updatePinCoordinates(with visibleRect: CGRect, zoomScale: CGFloat) {
       guard let coordinates = coordinates else { return }
        /*
         let xPos = (visibleRect.origin.x + (self.pdfContainerView.frame.width / 2)) / visibleRect.width
         let yPos = (visibleRect.origin.y + (self.pdfContainerView.frame.height / 2)) / visibleRect.height
         
         let xFactor: Double = Double(xPos * zoomScale)
         let yFactor: Double = Double(yPos * zoomScale)
         let latitude = -((yFactor * (coordinates.maxX - coordinates.minX)) - coordinates.maxX)
         let longitude = coordinates.minY + (xFactor * (coordinates.maxY - coordinates.minY))
         */
        
        let centerX = (visibleRect.origin.x + (self.pdfContainerView.frame.width / 2)) / visibleRect.width
        let centerY = (visibleRect.origin.y + (self.pdfContainerView.frame.width / 2)) / visibleRect.height
        
        // Normalize the positions based on the visible rect size
        let normalizedX = centerX / visibleRect.width
        let normalizedY = centerY / visibleRect.height
        
        // Calculate factors based on the zoom scale
        let xFactor: Double = Double(normalizedX * zoomScale)
        let yFactor: Double = Double(normalizedY * zoomScale)

        let latitude = coordinates.minX + (yFactor * (coordinates.maxX - coordinates.minX))
        let longitude = coordinates.minY + (xFactor * (coordinates.maxY - coordinates.minY))

            print("Updated Latitude: \(latitude), Longitude: \(longitude)")
        
        if isFirstLoad {
            isFirstLoad = false
        } else {
            if isSecondLoad {
                isSecondLoad = false
            } else {
                self.currentCoordinateLbl.text = "\(latitude)" + "," + "\(longitude)"
            }
        }
        if isPresentOnCoordinates() {
                print("Issuer is present at the current location.")
            } else {
                print("Issuer is NOT present at the current location.")
            }
        
        
        if isPresentOnCoordinates() {
            updateTrackingMarker()
            updateMarkerVisiblityOnPdfView()
        } else {
            removeMarkerFromPdfView()
        }
    }
}

// MARK: - Location manager delagates and current location tracker

extension MapPreviewViewController: CLLocationManagerDelegate {
    
    func showAlertWhenUserDeclineTheLocationPermission() {
        let alertController = UIAlertController(title: MapDetailScreenConstant.BlankStr, message: MapDetailScreenConstant.BlankStr, preferredStyle: UIAlertController.Style.alert)
        let myString  = "\(MapDetailScreenConstant.LocationAccessStr)\n"
        var myMutableString = NSMutableAttributedString()
        myMutableString = NSMutableAttributedString(string: myString as String, attributes: [NSAttributedString.Key.font:UIFont(name: MapDetailScreenConstant.GibsonBFont, size: 15.0)!])
        myMutableString.addAttribute(NSAttributedString.Key.foregroundColor, value: UIColor.black, range: NSRange(location:0,length:myString.count))
        alertController.setValue(myMutableString, forKey: MapDetailScreenConstant.AlertAttributeTitleStr)
        
        let message  = "\n\(MapDetailScreenConstant.LocationNewAccessMessageStr) \(MapDetailScreenConstant.LocationStepsFollowStr)"
        var messageMutableString = NSMutableAttributedString()
        messageMutableString = NSMutableAttributedString(string: message as String, attributes: [NSAttributedString.Key.font:UIFont(name:MapDetailScreenConstant.GibsonBFont, size: 13.0)!])
        messageMutableString.addAttribute(NSAttributedString.Key.foregroundColor, value: UIColor.darkGray, range: NSRange(location:0,length:61))
        messageMutableString.addAttribute(NSAttributedString.Key.foregroundColor, value: UIColor.black, range: NSRange(location:61,length:55))
        alertController.setValue(messageMutableString, forKey: MapDetailScreenConstant.AlertAttributeMesgStr)
        let action = UIAlertAction(title: MapDetailScreenConstant.OkStr, style: UIAlertAction.Style.default, handler: nil)
        action.setValue(UIColor.black, forKey: MapDetailScreenConstant.AlertAttributeTitileTextColourStr)
        alertController.addAction(action)
        self.present(alertController, animated: true, completion: nil)
    }
    
    func locationManager(_ manager: CLLocationManager,didChangeAuthorization status: CLAuthorizationStatus ) {
        print("Locaiton Permission:- \(CLLocationManager.authorizationStatus())")
        switch CLLocationManager.authorizationStatus() {
        case .denied,.restricted:
            showAlertWhenUserDeclineTheLocationPermission()
        case .authorizedAlways,.authorizedWhenInUse:
            print("Locaiton Authorized")
            initCurrentLocation()
        case .notDetermined:
            print("Locaiton Not Determined")
            locationManager.requestAlwaysAuthorization()
        @unknown default:
            break;
        }
    }
    
    func initCurrentLocation() {
        locationManager.delegate = self
        locationManager.desiredAccuracy = kCLLocationAccuracyBest
        locationManager.requestAlwaysAuthorization()
        
        if CLLocationManager.locationServicesEnabled() {
            locationManager.desiredAccuracy = kCLLocationAccuracyBest
            locationManager.startUpdatingLocation()
        }
    }
    
    
    func locationManager(_ manager: CLLocationManager, didUpdateLocations locations: [CLLocation]) {
        guard let locValue: CLLocationCoordinate2D = manager.location?.coordinate else { return }
        self.currentLocation = locValue
        if isPresentOnCoordinates() {
            print("Called didUpdateLocations ")
            let userLoggedIn = UserDefaultsUtils.retriveUserLoggedInValue(keyValue: UserProfileKeys.isLoggedInMapScreen.rawValue)
            if userLoggedIn {
                print("In Class Called didUpdateLocations ")
                addTrackingMarker()
                updateMarkerVisiblityOnPdfView()
                getCurrentLocMakerOutSideFrameOrNot()
            }else{
                print("Out Class Called didUpdateLocations ")
            }
        } else {
            removeMarkerFromPdfView()
        }
    }
    
    func getCurrentLocMakerOutSideFrameOrNot() {
        var visibleRect = CGRect.init(x: 0, y: 0, width: 0, height: 0)
        visibleRect.origin = pdfController!.scrollView.contentOffset
        visibleRect.size = pdfController!.scrollView.bounds.size
        
        print("Pdf Controller ScrollView ","\ny = ",visibleRect.origin.y,"\nx = ",visibleRect.origin.x,"\nCurrent Marker View ","\ny = ",currentmarkerImagView.frame.origin.y,"\nx = ",currentmarkerImagView.frame.origin.x)
        
        if !visibleRect.intersects(currentmarkerImagView.frame) {
            print("Outer View")
            guard let locValue: CLLocationCoordinate2D = self.currentLocation else { return }
            guard let coordinates = coordinates else { return }
            
            let yFactor = (locValue.longitude - coordinates.minY) / (coordinates.maxY - coordinates.minY)
            let xFactor = (coordinates.maxX - locValue.latitude) / (coordinates.maxX - coordinates.minX)
            
            var positionX: Double = 0.0
            var positionY: Double = 0.0
            
            positionX = (yFactor*Double(visibleScrollViewRect!.size.width))/Double(self.zooomLevel!)
            positionY = (xFactor*Double(visibleScrollViewRect!.size.height))/Double(self.zooomLevel!)
            
            if visibleScrollViewRect!.size.width <  1.0 {
                positionX = (yFactor*Double(18))*Double(self.zooomLevel!)
                positionY = (xFactor*Double(18))*Double(self.zooomLevel!)
            }
            let centerPoint = CGPoint(x: positionX-207, y: positionY-328)
            //let centerPoint = CGPoint(x: positionX , y: positionY )
            UIView.animate(withDuration: 2, animations: {
                self.pdfController!.scrollView.setContentOffset(centerPoint, animated: false)
                self.pdfController!.scrollView.setZoomScale(self.pdfController!.scrollView.zoomScale/2, animated: false)
            })
            
            // Without Custom Set X and Y points
//             let centerPoint = CGPoint(x: positionX , y: positionY )
//             UIView.animate(withDuration: 3, animations: {
//             self.pdfController!.scrollView.setContentOffset(centerPoint, animated: false)
//             self.pdfController!.scrollView.setZoomScale(self.pdfController!.scrollView.zoomScale/2, animated: false)
//             })
        }
    }
    
    func locationManager(_ manager: CLLocationManager, didFailWithError error: Error) {
        
    }
    
//    func isPresentOnCoordinates() -> Bool {
//        
//        guard let coordinates = coordinates else { return false }
//        
//        let bottom = coordinates.minY
//        let left = coordinates.minX
//        let top = coordinates.maxY
//        let right = coordinates.maxX
//        
//        if checkLocationInBounds(top: top, right: right, bottom: bottom, left: left) {
//            return true
//        } else {
//            return false
//        }
//        return false
//    }
//    
//    private func checkLocationInBounds(top: Double, right: Double, bottom: Double, left: Double) -> Bool {
//        guard let locValue: CLLocationCoordinate2D = self.currentLocation else { return false }
//        return locValue.latitude > left && locValue.latitude < right && locValue.longitude < top && locValue.longitude > bottom
//    }
    func isPresentOnCoordinates() -> Bool {
        guard let coordinates = coordinates else { return false }
        
        let bottom = coordinates.minY // Minimum latitude
        let left = coordinates.minX   // Minimum longitude
        let top = coordinates.maxY     // Maximum latitude
        let right = coordinates.maxX    // Maximum longitude
        
        return checkLocationInBounds(top: top, right: right, bottom: bottom, left: left)
    }

    // Check if the current location is within the defined bounds
    private func checkLocationInBounds(top: Double, right: Double, bottom: Double, left: Double) -> Bool {
        guard let locValue: CLLocationCoordinate2D = self.currentLocation else { return false }
        
        // Check if the location is within bounds
        return locValue.latitude > bottom && locValue.latitude < top && locValue.longitude > left && locValue.longitude < right
    }

    func updateMarkerVisiblityOnPdfView() {
        guard let locValue: CLLocationCoordinate2D = self.currentLocation else { return }
       guard let coordinates = coordinates else { return }
        
        let yFactor = (locValue.longitude - coordinates.minY) / (coordinates.maxY - coordinates.minY)
        let xFactor = (coordinates.maxX - locValue.latitude) / (coordinates.maxX - coordinates.minX)
        
       print("XFactor \(xFactor), YFactor \(yFactor)")
        var positionX: Double = 0.0
        var positionY: Double = 0.0
        
        positionX = (yFactor*Double(visibleScrollViewRect!.size.width))/Double(self.zooomLevel!)
        positionY = (xFactor*Double(visibleScrollViewRect!.size.height))/Double(self.zooomLevel!)
        
        if visibleScrollViewRect!.size.width < 1.0 {
            positionX = (yFactor*Double(18))*Double(self.zooomLevel!)
            positionY = (xFactor*Double(18))*Double(self.zooomLevel!)
        }
        
        var indexOfExistingImageView: Int?
        
        for index in 0..<pdfController!.scrollView.subviews.count {
            if let imageview = pdfController!.scrollView.subviews[index] as? UIImageView {
                if imageview.image == currentmarkerImagView.image {
                    indexOfExistingImageView = index
                }
            }
        }
        
        if let imageSubviewIndex = indexOfExistingImageView {
            if let imageViewReference = pdfController!.scrollView.subviews[imageSubviewIndex] as? UIImageView {
                // update postion
                imageViewReference.center = .init(x: positionX, y: positionY)
                self.pdfController!.scrollView.bringSubviewToFront(imageViewReference)
            }
        } else {
            self.currentmarkerImagView.center = .init(x: positionX, y: positionY)
            self.pdfController!.scrollView.addSubview(currentmarkerImagView)
            self.pdfController!.scrollView.bringSubviewToFront(currentmarkerImagView)
        }
    }
    
    func removeMarkerFromPdfView() {
        for subview in pdfController!.contentView.subviews where subview == currentmarkerImagView {
            subview.removeFromSuperview()
        }
    }
    
    func addTrackingMarker() {
        guard let locValue: CLLocationCoordinate2D = self.currentLocation else { return }
        guard let coordinates = coordinates else { return }
//
        let yFactor = (locValue.longitude - coordinates.minY) / (coordinates.maxY - coordinates.minY)
        let xFactor = (coordinates.maxX - locValue.latitude) / (coordinates.maxX - coordinates.minX)
        
        var positionX: Double = 0.0
        var positionY: Double = 0.0
        
        positionX = (yFactor*Double(visibleScrollViewRect!.size.width))/Double(self.zooomLevel!)
        positionY = (xFactor*Double(visibleScrollViewRect!.size.height))/Double(self.zooomLevel!)
        
        if visibleScrollViewRect!.size.width < 1.0 {
            positionX = (yFactor*Double(8.0))*Double(self.zooomLevel!)
            positionY = (xFactor*Double(8.0))*Double(self.zooomLevel!)
        }
//        
        let trackingMarkerImagView: UIImageView = {
            let imageView = UIImageView.init(frame: CGRect.init(x: 0, y: 0, width: 10, height: 10))
            imageView.image = #imageLiteral(resourceName: "ic_track")
            return imageView
        }()
        
        self.pdfController!.scrollView.addSubview(trackingMarkerImagView)
        trackingMarkerImagView.center = .init(x: positionX, y: positionY)
        self.trackingLocations.append(locValue)
        guard let lastMarker = self.pdfController!.scrollView.subviews.last as? UIImageView else { return }
        self.trackingMarkers.append(lastMarker)
        
        mapSaveResource.getRecordAllLocalTracks(isComeFromMapScreen:true,SessionId:  returnSessionId(isGet: true)) { [self] responseArray, responsseStatus in
            let getDistnceMthdResopnse = getDistanceBetweenTwoLocationWhenUserMove(currentLocation: CLLocationCoordinate2D(latitude: self.currentLocation!.latitude, longitude: self.currentLocation!.longitude))
            //print("getDistnceMthdResopnse = ",getDistnceMthdResopnse)
            if getDistnceMthdResopnse.0 {
                if responseArray.count > 0 {
                    self.mapSaveResource.insertRecordWithLatestNameInLatLongTbl(SessionId:   returnSessionId(isGet: true), mapFileID: mapItem!.mapFileID, latitude: self.currentLocation!.latitude, longitude: self.currentLocation!.longitude,distance:getDistnceMthdResopnse.1) { response in }
                } else {
                    self.mapSaveResource.insertRecordWithLatestName(SessionId:   returnSessionId(isGet: true), mapFile: mapItem!.mapFile, mapFileID: mapItem!.mapFileID, mapFileName: mapItem!.mapFileName ?? MapDetailScreenConstant.BlankStr, latestName: MapDetailScreenConstant.BlankStr,mapInfoJSON:mapItem!.mapInfoJSON!, CreatedTimeStamp: "\(NSDate().timeIntervalSince1970)") { response in }
                }
            }
        }
        updateMarkerVisiblityOnPdfView()
    }
    
    func getDistanceBetweenTwoLocationWhenUserMove(currentLocation:CLLocationCoordinate2D) -> (Bool,Int) {
        var returnStatusInRangeOrNot = false
        var returnDistance = 0
        if previousLocation == nil {
            previousLocation  = CLLocation(latitude:  currentLocation.latitude, longitude: currentLocation.longitude)
        }
        
        let currentLocation = CLLocation(latitude: currentLocation.latitude, longitude: currentLocation.longitude)
        let previousLocation1 = CLLocation(latitude: previousLocation!.coordinate.latitude, longitude: previousLocation!.coordinate.longitude)
        //print("currentLocation = ",currentLocation.coordinate,"previousLocation = ",previousLocation1.coordinate)
        if currentLocation.coordinate.latitude != previousLocation1.coordinate.latitude && currentLocation.coordinate.longitude != previousLocation1.coordinate.longitude {
            returnDistance = Int(currentLocation.distance(from: previousLocation1).rounded())
            //print("currentLocation = ",currentLocation.coordinate,"previousLocation = ",previousLocation1.coordinate,"returnDistance = ",returnDistance)
            if returnDistance > 1 {
                returnStatusInRangeOrNot = true
                previousLocation  = currentLocation
                distanceBetween = returnDistance
            }
        }
        return (returnStatusInRangeOrNot,returnDistance)
    }
    
    
    
    func updateTrackingMarker() {
        for index in 0..<trackingLocations.count {
            guard let coordinates = coordinates else { return }
            
            let locValue = trackingLocations[index]
            let yFactor = (locValue.longitude - coordinates.minY) / (coordinates.maxY - coordinates.minY)
            let xFactor = (coordinates.maxX - locValue.latitude) / (coordinates.maxX - coordinates.minX)
            
            var positionX: Double = 0.0
            var positionY: Double = 0.0
            
            positionX = (yFactor*Double(visibleScrollViewRect!.size.width))/Double(self.zooomLevel!)
            positionY = (xFactor*Double(visibleScrollViewRect!.size.height))/Double(self.zooomLevel!)
            
            if visibleScrollViewRect!.size.width < 1.0 {
                positionX = (yFactor*Double(8.0))*Double(self.zooomLevel!)
                positionY = (xFactor*Double(8.0))*Double(self.zooomLevel!)
            }
            self.trackingMarkers[index].center = .init(x: positionX, y: positionY)
        }
    }
}

extension MapPreviewViewController {
    
    func returnSessionId(isGet:Bool) -> Int{
        var useSessionId = 0
        useSessionId = UserDefaultsUtils.retriveSessionIdForLocalDatabase(keyValue: UserProfileKeys.isSessionId.rawValue)
        if !isGet {
            UserDefaultsUtils.saveSessionIdForLocalDatabase(useSessionId + 1, keyValue: UserProfileKeys.isSessionId.rawValue)
            useSessionId = UserDefaultsUtils.retriveSessionIdForLocalDatabase(keyValue: UserProfileKeys.isSessionId.rawValue)
        }
        print("userSessionId = ",useSessionId)
        return useSessionId
    }
    
    func addMarkerForPath(indexValuelat:Double,indexValuelong:Double) {
        localTempLocation = CLLocationCoordinate2D(latitude: indexValuelat, longitude: indexValuelong)
        guard let locValue: CLLocationCoordinate2D = self.localTempLocation else { return }
        guard let coordinates = coordinates else { return }
        
        let yFactor = (locValue.longitude - coordinates.minY) / (coordinates.maxY - coordinates.minY)
        let xFactor = (coordinates.maxX - locValue.latitude) / (coordinates.maxX - coordinates.minX)
        
        var positionX: Double = 0.0
        var positionY: Double = 0.0
        
        positionX = (yFactor*Double(visibleScrollViewRect!.size.width))/Double(self.zooomLevel!)
        positionY = (xFactor*Double(visibleScrollViewRect!.size.height))/Double(self.zooomLevel!)
        
        if visibleScrollViewRect!.size.width < 1.0 {
            positionX = (yFactor*Double(8.0))*Double(self.zooomLevel!)
            positionY = (xFactor*Double(8.0))*Double(self.zooomLevel!)
        }
        
        let trackingMarkerImagView: UIImageView = {
            let imageView = UIImageView.init(frame: CGRect.init(x: 0, y: 0, width: 10, height: 10))
            imageView.image = #imageLiteral(resourceName: "ic_trackAlready")
            return imageView
        }()
        
        self.pdfController!.scrollView.addSubview(trackingMarkerImagView)
        trackingMarkerImagView.center = .init(x: positionX, y: positionY)
        self.trackingLocations.append(locValue)
        guard let lastMarker = self.pdfController!.scrollView.subviews.last as? UIImageView else { return }
        self.trackingMarkers.append(lastMarker)
    }
    
    func showAlertWhenUserClickBackButton(title:String,message:String,isForSaveName:Bool,FirstButtonName:String,SecondButtonName:String) {
        let alert = UIAlertController(title: title, message: message, preferredStyle: UIAlertController.Style.alert)
        
        if isForSaveName {
            alert.addTextField { (textField : UITextField!) -> Void in
                textField.placeholder = MapDetailScreenConstant.EnterPDFNameStr.replacingOccurrences(of: MapDetailScreenConstant.PleaseStr, with: MapDetailScreenConstant.BlankStr)
            }}
        
        alert.addAction(UIAlertAction(title: FirstButtonName, style: UIAlertAction.Style.default, handler: { actionResponse in
            if FirstButtonName == MapDetailScreenConstant.SaveStr {
                self.showAlertWhenUserClickBackButton(title: MapDetailScreenConstant.BlankStr, message: MapDetailScreenConstant.EnterPDFNameStr.replacingOccurrences(of: MapDetailScreenConstant.PleaseStr, with: MapDetailScreenConstant.BlankStr), isForSaveName: true, FirstButtonName: MapDetailScreenConstant.YesStr, SecondButtonName: MapDetailScreenConstant.NoStr)
            }else if FirstButtonName == MapDetailScreenConstant.YesStr {
                let textField = alert.textFields![0]
                if textField.text ==  MapDetailScreenConstant.BlankStr {
                    ToastUtils.shared.showToast(with: MapDetailScreenConstant.EnterPDFNameStr)
                }else{
                    let checkAlreadyExistName = self.delegate?.checkNameExistOrNot(pdfName: textField.text!)
                    if checkAlreadyExistName != nil {
                        if checkAlreadyExistName! {
                            ToastUtils.shared.showToast(with: MapDetailScreenConstant.EnterDifferentPDFNameStr)
                        }else{
                            self.mapSaveResource.updateRecordWithLatestName(latestName: textField.text!, SessionId:  self.returnSessionId(isGet: true)) { response in
                                if response {
                                    self.dismissView(isComeFromSaveAlert: true)
                                }
                            }
                        }
                    }
                }
            }
        }))
        
        alert.addAction(UIAlertAction(title: SecondButtonName, style: UIAlertAction.Style.destructive, handler: { actionResponse in
            if SecondButtonName == MapDetailScreenConstant.CancelStr {
                self.mapSaveResource.deleteRecordWithLatestName(comeFromMapScreen: true, SessionId:  self.returnSessionId(isGet: true)) { response
                    in
                    if response {
                        ToastUtils.shared.showToast(with: MapDetailScreenConstant.ClearTrackingStr)
                    }
                    DispatchQueue.main.asyncAfter(deadline: .now()+2.5) {
                        self.dismissView(isComeFromSaveAlert: false)
                    }
                }
            }
        }))
        self.present(alert, animated: true, completion: nil)
    }
    
    
    func getLocalPointsWithParticularSessionId(){
        if isComeFromMapScreen {
            if mapItem!.sessionIdLocal != nil {
                mapSaveResource.getAllRecordWithParticularSessionId(SessionId: mapItem!.sessionIdLocal!) { responseArry, responseStatus in
                    for i in 0..<responseArry.count{
                        let mapFileInfo = responseArry[i] as? LatLongDetailTable
                        self.addMarkerForPath(indexValuelat: mapFileInfo!.Latitude!, indexValuelong: mapFileInfo!.Longitude!)
                    }
                }
            }
        }
    }
    
    func dismissView(isComeFromSaveAlert:Bool){
        UserDefaultsUtils.saveUserLoggedInValue(false, keyValue: UserProfileKeys.isLoggedInMapScreen.rawValue)
        if isComeFromSaveAlert {
            self.delegate?.updateMainViewControllerLocalResponse(isBack: true)
        }
        let _ = returnSessionId(isGet: false)
        self.navigationController?.popViewController(animated: true)
    }
}
struct PDFCoordinateBounds {
    let xMin: Double
    let yMin: Double
    let xMax: Double
    let yMax: Double
}


